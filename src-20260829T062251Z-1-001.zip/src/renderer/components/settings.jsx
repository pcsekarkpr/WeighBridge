import React, { useState } from 'react';
import MasterDataManagement from './MasterDataManagement';
import PrinterSettingsManagement from './PrinterSettingsManagement';

export default function SettingsView({ onClose }) {
  const [settingsSubView, setSettingsSubView] = useState('MAIN'); // 'MAIN', 'MASTERS', 'PRINTER'

  // Global keydown helper inside settings view
  React.useEffect(() => {
    const handleSettingsKeyDown = (e) => {
      if (e.key === 'Escape' && settingsSubView === 'MAIN') {
        e.preventDefault();
        onClose(); // Exit to main dashboard
      }
    };
    window.addEventListener('keydown', handleSettingsKeyDown);
    return () => window.removeEventListener('keydown', handleSettingsKeyDown);
  }, [settingsSubView, onClose]);

  // Render Sub-Views dynamically
  if (settingsSubView === 'MASTERS') {
    return <MasterDataManagement onBack={() => setSettingsSubView('MAIN')} />;
  }

  if (settingsSubView === 'PRINTER') {
    return <PrinterSettingsManagement onBack={() => setSettingsSubView('MAIN')} />;
  }

  return (
    <div className="fixed inset-0 bg-slate-100 z-40 flex flex-col p-4 font-sans select-none overflow-hidden h-screen w-screen">
      {/* Header */}
      <header className="bg-white rounded-xl shadow-sm px-6 py-3 flex justify-between items-center mb-4 border border-slate-200 shrink-0">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-slate-800 flex items-center gap-2">
            <span>⚙️ System Control Panel</span>
          </h1>
          <p className="text-xs font-bold text-slate-400 tracking-wider">CONFIGURATION & REGISTERS</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="bg-slate-800 hover:bg-slate-900 text-white font-black px-5 py-2 rounded-xl text-sm shadow transition flex flex-col items-center justify-center border border-slate-950"
        >
          <span>✕ CLOSE SETTINGS</span>
          <span className="text-[10px] font-medium opacity-70">[ESC]</span>
        </button>
      </header>

      {/* Main Settings Navigation System */}
      <div className="flex-grow flex items-center justify-center max-w-4xl mx-auto w-full px-4">
        <div className="grid grid-cols-2 gap-6 w-full">
          
          {/* Button 1: Master Registry */}
          <button
            type="button"
            onClick={() => setSettingsSubView('MASTERS')}
            className="bg-white hover:bg-indigo-50/50 border-2 border-slate-200 hover:border-indigo-500 rounded-2xl p-8 shadow-sm hover:shadow-md transition text-left flex flex-col justify-between h-64 group outline-none focus:ring-4 focus:ring-indigo-100"
          >
            <div className="w-14 h-14 bg-indigo-100 rounded-xl flex items-center justify-center text-3xl group-hover:scale-110 transition">
              👥
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-800 mb-1">Parties & Materials</h2>
              <p className="text-sm font-medium text-slate-500 leading-relaxed">
                Add, manage, and delete customer names and raw material variants from a consolidated single-screen register.
              </p>
            </div>
            <span className="text-xs font-bold text-indigo-600 tracking-wider uppercase group-hover:translate-x-1 transition">
              Open Master Management →
            </span>
          </button>

          {/* Button 2: Printer Setup */}
          <button
            type="button"
            onClick={() => setSettingsSubView('PRINTER')}
            className="bg-white hover:bg-amber-50/50 border-2 border-slate-200 hover:border-amber-500 rounded-2xl p-8 shadow-sm hover:shadow-md transition text-left flex flex-col justify-between h-64 group outline-none focus:ring-4 focus:ring-amber-100"
          >
            <div className="w-14 h-14 bg-amber-100 rounded-xl flex items-center justify-center text-3xl group-hover:scale-110 transition">
              🖨️
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-800 mb-1">Printer Profiles</h2>
              <p className="text-sm font-medium text-slate-500 leading-relaxed">
                Configure ticket layout setups, serial parameters, toggle auto-print engines, and choose target hardware environments.
              </p>
            </div>
            <span className="text-xs font-bold text-amber-600 tracking-wider uppercase group-hover:translate-x-1 transition">
              Configure Print Engine →
            </span>
          </button>

        </div>
      </div>
    </div>
  );
}