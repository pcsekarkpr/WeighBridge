import { defineConfig } from 'vite';
// If you use vite-plugin-electron, import it here

export default defineConfig({
  build: {
    rollupOptions: {
      // Tell Vite absolutely NOT to bundle serialport or its C++ components
      external: [
        'serialport',
        '@serialport/bindings-cpp'
      ]
    }
  }
});